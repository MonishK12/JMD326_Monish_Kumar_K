// lib/pubnub.js
import PubNub from 'pubnub';

const pubnub = new PubNub({
  publishKey: process.env.publishKey as string,  // Your publish key
  subscribeKey: process.env.subscribeKey as string, // Your subscribe key
  secretKey: process.env.secretKey as string, // Optional: Use if you need advanced features
});

export default pubnub;
