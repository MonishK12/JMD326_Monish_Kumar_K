import { getCourses } from "@/actions/get-courses";
import { useUser } from "@clerk/nextjs"
import { db } from "@/lib/db";

import Categories from "./_components/Categories";
import { redirect } from "next/navigation";
import CoursesList from "@/components/Course/CoursesList";

interface SearchPageProps {
  searchParams: {
    title: string,
    categoryId: string
  }
}

const Searchpage = async ({searchParams}: SearchPageProps) => {
  const {user} = useUser();
  if(!user?.id) {
    return redirect("/");
  }

  const categories = await db.category.findMany();
  const courses = await getCourses({
    userId: user.id,
    ...searchParams,
  })

  return (
    <>
      <Categories items={categories}/>
      <div className="px-6 overflow-y-scroll bg-secondary mx-0 md:mx-auto py-6 rounded-none md:h-[calc(100vh-170px)] md:rounded-none md:rounded-bl-3xl md:mt-1 md:rounded-tl-xl container">
        <CoursesList items={courses} />
      </div>
    </>
  );
};

export default Searchpage;
