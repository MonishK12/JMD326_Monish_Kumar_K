"use client";

import axios from "axios";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { useUser } from "@clerk/nextjs"; // Import Clerk's useUser hook

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea"; // Make sure to import your textarea component
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

// Define form validation schema
const feedbackSchema = z.object({
  courseRating: z.number().min(1).max(5).int().optional(), // Rating for the course
  quizRating: z.number().min(1).max(5).int().optional(), // Rating for the quiz
  instructorRating: z.number().min(1).max(5).int().optional(), // Rating for the instructor
  contentRating: z.number().min(1).max(5).int().optional(),
  satisfaction: z.number().min(1).max(5).int().optional(), // Rating for content relevance
  comments: z.string().optional(), // Optional comments
});

function FeedbackForm() {
  const router = useRouter();
  const { user } = useUser(); // Access the authenticated user details
  const [isLoading, setIsLoading] = useState(false);

  // React Hook Form setup
  const form = useForm<z.infer<typeof feedbackSchema>>({
    resolver: zodResolver(feedbackSchema),
    defaultValues: {
      courseRating: undefined,
      quizRating: undefined,
      instructorRating: undefined,
      contentRating: undefined,
      satisfaction: undefined,
      comments: "",
    },
  });

  const { isValid, isSubmitting } = form.formState;

  // Submit handler
  const onSubmit = async (values: z.infer<typeof feedbackSchema>) => {
    try {
      setIsLoading(true);

      // Ensure the user object exists before accessing its properties
      if (!user) {
        toast.error("User is not authenticated.");
        return;
      }

      // Submit the feedback
      await axios.put("/api/feedback", {
        ...values,
        userId: user.id, // Add Clerk user ID to the request
      });

      toast.success("Feedback submitted successfully!");
      router.push("/dashboard"); // Redirect to dashboard after submission
    } catch (error) {
      console.error(error);
      toast.error("Something went wrong.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="py-6 md:p-10 bg-secondary/50 text-secondary-foreground md:rounded-3xl container max-w-3xl h-full flex flex-col items-start justify-center">
      <h1 className="font-bold text-xl sm:text-2xl md:text-3xl">
        Feedback Form
      </h1>
      <p className="text-muted-foreground mt-1 text-sm sm:text-base">
        Please rate the following aspects of the course and quiz.
      </p>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 mt-6 w-full">
        <FormField
  control={form.control}
  name="courseRating"
  render={({ field }) => (
    <FormItem>
      <FormLabel>Course Rating (1-5)</FormLabel>
      <FormControl>
        <Input
          type="number"
          min="1"
          max="5"
          placeholder="Rate the course"
          {...field}
          onChange={(e) => field.onChange(Number(e.target.value))} // Convert string to number
        />
      </FormControl>
      <FormMessage />
    </FormItem>
  )}
/>
<FormField
  control={form.control}
  name="quizRating"
  render={({ field }) => (
    <FormItem>
      <FormLabel>Quiz Rating (1-5)</FormLabel>
      <FormControl>
        <Input
          type="number"
          min="1"
          max="5"
          placeholder="Rate the quiz"
          {...field}
          onChange={(e) => field.onChange(Number(e.target.value))} // Convert string to number
        />
      </FormControl>
      <FormMessage />
    </FormItem>
  )}
/>
<FormField
  control={form.control}
  name="instructorRating"
  render={({ field }) => (
    <FormItem>
      <FormLabel>Instructor Rating (1-5)</FormLabel>
      <FormControl>
        <Input
          type="number"
          min="1"
          max="5"
          placeholder="Rate the instructor"
          {...field}
          onChange={(e) => field.onChange(Number(e.target.value))} // Convert string to number
        />
      </FormControl>
      <FormMessage />
    </FormItem>
  )}
/>
<FormField
  control={form.control}
  name="contentRating"
  render={({ field }) => (
    <FormItem>
      <FormLabel>Content Relevance Rating (1-5)</FormLabel>
      <FormControl>
        <Input
          type="number"
          min="1"
          max="5"
          placeholder="Rate content relevance"
          {...field}
          onChange={(e) => field.onChange(Number(e.target.value))} // Convert string to number
        />
      </FormControl>
      <FormMessage />
    </FormItem>
  )}
/>
<FormField
  control={form.control}
  name="satisfaction"
  render={({ field }) => (
    <FormItem>
      <FormLabel>Satisfaction Rating (1-5)</FormLabel>
      <FormControl>
        <Input
          type="number"
          min="1"
          max="5"
          placeholder="Rate satisfaction"
          {...field}
          onChange={(e) => field.onChange(Number(e.target.value))} // Convert string to number
        />
      </FormControl>
      <FormMessage />
    </FormItem>
  )}
/>
          <FormField
            control={form.control}
            name="comments"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Additional Comments (optional)</FormLabel>
                <FormControl>
                  <Textarea placeholder="Your comments..." {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <div className="flex w-full items-center justify-end gap-2 ml-auto">
            <Link href="/dashboard" type="button" className={buttonVariants({ variant: "ghost" })}>
              Cancel
            </Link>
            <Button type="submit" disabled={!isValid || isSubmitting || isLoading}>
    {isLoading ? <Loader2 className="mr-1 animate-spin p-1" /> : "Submit"}
  </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}

export default FeedbackForm;
